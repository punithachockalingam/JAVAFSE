package com.example.bookstoreapi.config;

import java.util.random.RandomGenerator;
import java.util.random.RandomGeneratorFactory;

public class GroupedOpenApi {
    public static RandomGeneratorFactory<RandomGenerator> builder() {
    }
}
