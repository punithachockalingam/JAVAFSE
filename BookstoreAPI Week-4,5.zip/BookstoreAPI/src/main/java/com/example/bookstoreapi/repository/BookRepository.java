package com.example.bookstoreapi.repository;

import com.example.bookstoreapi.model.Book;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
    Optional<Book> findById(Long id);

    List<Book> findAll();

    Book save(Book book);
    // You can define custom queries here if needed
}
