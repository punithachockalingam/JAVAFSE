package com.example.bookstoreapi.security;

import jakarta.servlet.Filter;

public abstract class JwtRequestFilter implements Filter {
}
