package com.example.bookstoreapi.controller;

public class CollectionModel<E> {
}
