package com.example.bookstoreapi.repository;


import com.example.bookstoreapi.model.Book;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface bookrepo extends JpaRepository<Book, Long>, BookRepository {
    @Override
    default Book save(Book book) {
        return null;
    }

    @Override
    default List<Book> findAll() {
        return List.of();
    }

    @Override
    default Optional<Book> findById(Long id) {
        return null;
    }
    // No implementation needed, Spring Data JPA will provide the implementation
}

