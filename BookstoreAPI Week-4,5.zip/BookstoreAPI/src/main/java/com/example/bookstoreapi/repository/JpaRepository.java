package com.example.bookstoreapi.repository;

import com.example.bookstoreapi.model.Book;

import java.util.List;
import java.util.Optional;

public interface JpaRepository<T, T1> {
    List<Book> findAll();

    Optional<Book> findById(Long id);
}
