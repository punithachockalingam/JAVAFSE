package com.example.bookstoreapi.model;

public class GenerationType {
    public class IDENTITY {
    }
}
