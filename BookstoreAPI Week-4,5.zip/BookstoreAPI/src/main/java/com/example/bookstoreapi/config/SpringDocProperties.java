package com.example.bookstoreapi.config;

public class SpringDocProperties {
}
