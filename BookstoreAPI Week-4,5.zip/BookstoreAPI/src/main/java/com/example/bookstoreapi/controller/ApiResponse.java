package com.example.bookstoreapi.controller;

public @interface ApiResponse {
    String responseCode();

    String description();
}
