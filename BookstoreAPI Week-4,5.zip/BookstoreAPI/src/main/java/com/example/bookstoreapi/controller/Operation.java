package com.example.bookstoreapi.controller;

public @interface Operation {
    String summary();

    String description();
}
