package com.example.bookstoreapi.controller;

public class EntityModel<T> {
}
