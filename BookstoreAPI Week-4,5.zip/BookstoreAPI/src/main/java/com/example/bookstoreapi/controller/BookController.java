package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.dto.BookDTO;
import com.example.bookstoreapi.exception.ResourceNotFoundException;
import com.example.bookstoreapi.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @Operation(summary = "Get a book by ID", description = "Fetch a book by its ID")

    @GetMapping(value = "/{id}", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public EntityModel<Optional<Book>> getBookById(@PathVariable Long id) {
        Optional<Book> bookDTO = bookService.getBookById(id); // Assuming this method returns a BookDTO

        if (bookDTO == null) {
            throw new ResourceNotFoundException("Book not found with id " + id); // Ensure ResourceNotFoundException is defined
        }

        EntityModel<Optional<Book>> resource = EntityModel.of(bookDTO);
        resource.add(WebMvcLinkBuilder.linkTo(
                WebMvcLinkBuilder.methodOn(BookController.class).getAllBooks()).withRel("all-books"));
        resource.add(WebMvcLinkBuilder.linkTo(
                WebMvcLinkBuilder.methodOn(BookController.class).getBookById(id)).withSelfRel());

        return resource;
    }

    @Operation(summary = "Get all books", description = "Fetch all books")
    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public CollectionModel<EntityModel<BookDTO>> getAllBooks() {
        List<EntityModel<BookDTO>> books = bookService.getAllBooks().stream()
                .map(bookDTO -> {
                    EntityModel<BookDTO> resource = EntityModel.of((BookDTO) bookDTO);
                    resource.add(WebMvcLinkBuilder.linkTo(
                            WebMvcLinkBuilder.methodOn(BookController.class).getBookById(bookDTO.getId())).withSelfRel());
                    return resource;
                })
                .collect(Collectors.toList());

        return CollectionModel.of(books);
    }
}
