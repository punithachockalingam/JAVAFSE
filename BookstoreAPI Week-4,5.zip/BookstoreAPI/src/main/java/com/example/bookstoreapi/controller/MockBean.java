package com.example.bookstoreapi.controller;

public @interface MockBean {
}
