package com.example.bookstoreapi.model;

public @interface Size {
    int min();

    int max();
}
