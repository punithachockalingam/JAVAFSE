package ProxyPatternExample;

public interface Image {
    void display();
}

